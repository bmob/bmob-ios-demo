//
//  ChatObject.m
//  BmobDataDemo
//
//  Created by Bmob on 14-7-21.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import "ChatObject.h"

@implementation ChatObject
@synthesize name,content,time;

@end
