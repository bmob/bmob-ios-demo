//
//  CloudFViewController.m
//  CloudFunction
//
//  Created by Bmob on 14-5-20.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import "CloudFViewController.h"
#import <BmobSDK/Bmob.h>

@interface CloudFViewController (){
    
    UITextView      *_resultTextView;
    
}

@end

@implementation CloudFViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        
        
        
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"云端代码";
    UIButton    *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn setTitle:@"run" forState:UIControlStateNormal];
    btn.frame        = CGRectMake(20, 64, 60, 40);
    [btn addTarget:self action:@selector(cloudFunction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    _resultTextView = [[UITextView alloc] initWithFrame:CGRectMake(10, 100, 300, 80)];
    [self.view addSubview:_resultTextView];
    _resultTextView.text = @"点击run，运行代码";
}


-(void)cloudFunction{
    //云端接收的参数对象，request对象可以获取到
    NSDictionary  *dic = [NSDictionary  dictionaryWithObject:@"bmob" forKey:@"name"];
    [BmobCloud callFunctionInBackground:@"你在bmob中创建的云端代码名称" withParameters:dic block:^(id object, NSError *error) {
        
        if (!error) {
            //执行成功时调用，返回object对象
            NSLog(@"error %@",[object description]);
            
            _resultTextView.text =[object description];
            
        }else{
            //执行失败时调用error
            NSLog(@"error %@",[error description]);
        }
        
    }] ;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
