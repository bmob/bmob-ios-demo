//
//  main.m
//  Feedback
//
//  Created by Bmob on 14-5-7.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BmobSDK/Bmob.h>
#import "AppDelegate.h"

int main(int argc, char * argv[])
{

    //可更换为您的应用的key
    [Bmob registerWithAppKey:@"3124f50157a5df138aba77a85e1d8909"];
    
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
