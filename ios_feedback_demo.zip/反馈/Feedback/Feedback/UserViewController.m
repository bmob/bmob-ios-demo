//
//  UserViewController.m
//  Feedback
//
//  Created by Bmob on 14-5-7.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import "UserViewController.h"
#import <BmobSDK/Bmob.h>

@interface UserViewController ()<UITextViewDelegate>

@end

@implementation UserViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"发送反馈";
    self.view.backgroundColor = [UIColor colorWithRed:242.0f/255 green:242.0f/255 blue:242.0f/255 alpha:1.0f];
    
    UIImageView  *backgroundImageView = [[UIImageView alloc] init];
    backgroundImageView.frame         = CGRectMake(0,  64+35, 320, 35);
    backgroundImageView.image         = [UIImage imageNamed:@"login_input"];
    [self.view addSubview:backgroundImageView];
    
    //练习方式
    UITextField *contactTextfield = [[UITextField alloc] init];
    contactTextfield.frame        = CGRectMake(16, 64+42, 288, 17);
    contactTextfield.font         = [UIFont systemFontOfSize:14];
    contactTextfield.placeholder  = @"联系方式";
    contactTextfield.tag          = 100;
    [self.view addSubview:contactTextfield];
    
    
    UIImageView  *backgroundImageView1 = [[UIImageView alloc] init];
    backgroundImageView1.frame         = CGRectMake(0,  64+27+60, 320, 73);
    backgroundImageView1.image         = [UIImage imageNamed:@"login_input"];
    [self.view addSubview:backgroundImageView1];
    
    UILabel *ncLabel                  = [[UILabel alloc] init];
    ncLabel.backgroundColor           = [UIColor clearColor];
    ncLabel.font                      = [UIFont boldSystemFontOfSize:15];
//    ncLabel.textColor                 = [uico];
    ncLabel.frame                     = CGRectMake(16, 64+42+60, 42, 17);
    ncLabel.text                      = @"留言";
    [self.view addSubview:ncLabel];
    
    
    
    UITextView     *ncTextView = [[UITextView alloc] init];
    ncTextView.frame            = CGRectMake(62,  64+33+60, 250, 60);
    ncTextView.font             = [UIFont systemFontOfSize:14];
    ncTextView.backgroundColor  = [UIColor clearColor];
    ncTextView.returnKeyType    = UIReturnKeyDone;
    ncTextView.delegate         = self;
    [self.view addSubview:ncTextView];
    ncTextView.tag              = 101;
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)sendFeedback{
    UITextField *contactTextfield = (UITextField *)[self.view viewWithTag:100];
    if ([contactTextfield.text length] == 0) {
        return;
    }
    
    UITextView     *ncTextView = (UITextView*)[self.view viewWithTag:101];
    if ([ncTextView.text length] == 0) {
        return;
    }
    
    BmobObject *feedbackObj = [[BmobObject alloc] initWithClassName:@"Feedback"];
    [feedbackObj setObject:contactTextfield.text forKey:@"contact"];
    [feedbackObj setObject:ncTextView.text forKey:@"content"];
    [feedbackObj saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //发送推送
            BmobPush *push = [BmobPush push];
            BmobQuery *query = [BmobInstallation query];
            //条件为isDeveloper是true
            [query whereKey:@"isDeveloper" equalTo:[NSNumber numberWithBool:YES] ];
            [push setQuery:query];
            //推送内容为反馈的内容
            [push setMessage:ncTextView.text];
            [push sendPushInBackgroundWithBlock:^(BOOL isSuccessful, NSError *error) {
                NSLog(@"push error =====>%@",[error description]);
            }];
        }
    }];
    
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text; {
    
    if ([@"\n" isEqualToString:text] == YES) {
        [self sendFeedback];
        return NO;
    }
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
