//
//  AppDelegate.m
//  ReadFeedback
//
//  Created by Bmob on 14-5-16.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import "AppDelegate.h"
#import "DeveloperViewController.h"
#import <BmobSDK/Bmob.h>

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
        [application registerForRemoteNotificationTypes:UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound];
    
    
    DeveloperViewController *mvc   = [[DeveloperViewController alloc] init];
    
    UINavigationController  *dnc   = [[UINavigationController alloc] initWithRootViewController:mvc];
    
    self.window                    = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor    = [UIColor whiteColor];

    self.window.rootViewController = dnc;
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    NSLog(@"userInfo %@",[userInfo description]);
    [BmobPush handlePush:userInfo];
}

-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{
    [self developerInstall:deviceToken];
}

/**
 * 本例子程序，是以本台手机作为开发者接收推送的设备 ，主要是演示推送功能。
 * 故如果是开发者的话会在Installation添加字段isDeveloper并设置为true，普通用户则设置为false
 */

-(void)developerInstall:(NSData*)deviceToken{
    BmobInstallation    *installation = [BmobInstallation currentInstallation];
    [installation setDeviceTokenFromData:deviceToken];
    [installation setObject:[NSNumber numberWithBool:YES] forKey:@"isDeveloper"];
    [installation saveInBackground];
}

-(void)userInstall:(NSData*)deviceToken{
    BmobInstallation    *installation = [BmobInstallation currentInstallation];
    [installation setObject:[NSNumber numberWithBool:NO] forKey:@"isDeveloper"];
    [installation setDeviceTokenFromData:deviceToken];
    //用户订阅sport频道的内容
    [installation subsccribeToChannels:@[@"sport"]];
    [installation saveInBackground];
}

@end
