//
//  DeveloperViewController.m
//  Feedback
//
//  Created by Bmob on 14-5-7.
//  Copyright (c) 2014年 bmob. All rights reserved.
//

#import "DeveloperViewController.h"
#import <BmobSDK/Bmob.h>

@interface DeveloperViewController ()<UITableViewDelegate,UITableViewDataSource>{
    UITableView         *_feedbackTableView;
    NSMutableArray      *_feedbacksArray;
}

@end

@implementation DeveloperViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(id)init{
    self = [super init];
    if (self) {
        if (IS_iOS7) {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"反馈信息";
    self.view.backgroundColor = [UIColor colorWithRed:242.0f/255 green:242.0f/255 blue:242.0f/255 alpha:1.0f];
    _feedbackTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, 320, ScreenHeight-64)];
    [_feedbackTableView setDelegate:self];
    [_feedbackTableView setDataSource:self];
    [self.view addSubview:_feedbackTableView];
    
    _feedbacksArray = [[NSMutableArray alloc] init];
    
    [self performSelector:@selector(searchFeedback) withObject:nil afterDelay:0.7f];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)searchFeedback{
    BmobQuery *query = [BmobQuery queryWithClassName:@"Feedback"];
    [query orderByDescending:@"updatedAt"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        for (BmobObject *obj in array) {
            NSMutableDictionary *dic = [NSMutableDictionary dictionary];
            [dic setObject:[obj objectForKey:@"content"] forKey:@"content"];
            [dic setObject:[obj objectForKey:@"contact"] forKey:@"contact"];
            [dic setObject:obj.createdAt forKey:@"time"];
            [_feedbacksArray addObject:dic];
            [_feedbackTableView reloadData];
        }
    }];
}

-(void)dealloc{
    [_feedbacksArray removeAllObjects];
    _feedbacksArray = nil;
    [_feedbackTableView setDataSource:nil];
    [_feedbackTableView setDelegate:nil];
}

#pragma mark - UITableView Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_feedbacksArray count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
 
    
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
     
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        
//        cell.contentView.backgroundColor = [UIColor colorWithRed:242.0f/255 green:242.0f/255 blue:242.0f/255 alpha:1.0f];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"内容:%@", [[[_feedbacksArray objectAtIndex:indexPath.row] objectForKey:@"content"] description]];
    
    
    
    return cell;
}

#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

@end
