//
//  UserDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "UserDemoViewController.h"
#import "Util.h"
#import <BmobSDK/Bmob.h>

@interface UserDemoViewController ()

@end

@implementation UserDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"用户注册",@"detail":@"registerByUsername"},
                       @{@"title":@"用户登录",@"detail":@"login"},
                       @{@"title":@"获取当前用户",@"detail":@"getCurrentUser"},
                       @{@"title":@"更新用户",@"detail":@"updateUser"},
                       @{@"title":@"查询用户",@"detail":@"queryUser"},
                       @{@"title":@"退出登录",@"detail":@"logoutUser"},
                       @{@"title":@"修改密码",@"detail":@"changePassword"},
                       @{@"title":@"微博登录",@"detail":@"weiboLogin"},
                       @{@"title":@"qq登录",@"detail":@"qqLogin"},
                       @{@"title":@"微信登录",@"detail":@"weixinLogin"},
                       @{@"title":@"绑定用户",@"detail":@"bindUser"},
                       @{@"title":@"解绑定用户",@"detail":@"unbindUser"},
                       @{@"title":@"手机注册",@"detail":@"mobilePhoneRegister"},
                       @{@"title":@"手机登录",@"detail":@"mobilePhoneLogin"},
                       @{@"title":@"绑定手机号",@"detail":@"bindMobilePhone"},
                       @{@"title":@"利用手机修改密码",@"detail":@"changePasswordByMobilePhone"},
                       @{@"title":@"邮箱验证",@"detail":@"emailVerify"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self registerByUsername];
        }
            break;
            
        case 1:{
            [self login];
        }
            break;
            
        case 2:{
            [self getCurrentUser];
        }
            break;
            
        case 3:{
            [self updateUser];
        }
            break;
            
        case 4:{
            [self queryUser];
        }
            break;
            
        case 5:{
            [self logoutUser];
        }
            break;
            
        case 6:{
            [self changePassword];
        }
            break;
            
        case 7:{
            [self weiboLogin];
        }
            break;
            
        case 8:{
            [self qqLogin];
        }
            break;
            
        case 9:{
            [self weixinLogin];
        }
            break;
            
        case 10:{
            [self bindUser];
        }
            break;
            
        case 11:{
            [self unbindUser];
        }
            break;
            
        case 12:{
            [self mobilePhoneRegister];
        }
            break;
            
        case 13:{
            [self mobilePhoneLogin];
        }
            break;
            
        case 14:{
            [self bindMobilePhone];
        }
            break;
            
        case 15:{
            [self changePasswordByMobilePhone];
        }
            break;
            
        case 16:{
            [self emailVerify];
        }
            
        default:
            break;
    }
}

#pragma mark - demo
- (void)registerByUsername{
    [Util batchDeleteUser];
    BmobUser *bUser = [[BmobUser alloc] init];
    [bUser setUserName:@"小明"];
    [bUser setPassword:@"123456"];
    [bUser setObject:@18 forKey:@"age"];
    [bUser signUpInBackgroundWithBlock:^ (BOOL isSuccessful, NSError *error){
        if (isSuccessful){
            NSLog(@"注册成功,%@",bUser);
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)login{
    [Util batchDeleteUser];
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}
                              ];
    [Util batchAddUserWithDataArray:addUserArray];
    [BmobUser loginWithUsernameInBackground:@"Lily" password:DEFAULTUSERPASSWORD block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"%@",user);
        }
    }];
}


- (void)getCurrentUser{
    [Util batchDeleteUser];
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}
                              ];
    [Util batchAddUserWithDataArray:addUserArray];
    [BmobUser loginWithUsernameInBackground:@"Lily" password:DEFAULTUSERPASSWORD block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            BmobUser *user = [BmobUser getCurrentUser];
            NSLog(@"%@",user);
        }
    }];
}

- (void)updateUser{
    [Util batchDeleteUser];
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}
                              ];
    [Util batchAddUserWithDataArray:addUserArray];
    
    [BmobUser loginWithUsernameInBackground:@"Lily" password:DEFAULTUSERPASSWORD block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            [user setObject:@30 forKey:@"number"];
            [user updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (error) {
                    NSLog(@"%@",error);
                } else {
                    NSLog(@"更新成功,%@",user);
                }
            }];
        }
    }];
    

}

- (void)queryUser{
    [Util batchDeleteUser];
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD}
                              ];
    [Util batchAddUserWithDataArray:addUserArray];
    BmobQuery *query = [BmobUser query];
    [query whereKey:@"username" equalTo:@"Lily"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        for (BmobUser *user in array) {
            NSLog(@"%@",user);
        }
    }];
}

- (void)logoutUser{
    [Util batchDeleteUser];
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}
                              ];
    [Util batchAddUserWithDataArray:addUserArray];
    [BmobUser loginWithUsernameInBackground:@"Lily" password:DEFAULTUSERPASSWORD block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            [BmobUser logout];
            BmobUser *user = [BmobUser getCurrentUser];
            NSLog(@"%@",user);
        }
    }];
}

- (void)changePassword{
    [Util batchDeleteUser];
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}
                              ];
    [Util batchAddUserWithDataArray:addUserArray];
    [BmobUser loginWithUsernameInBackground:@"Lily" password:DEFAULTUSERPASSWORD block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            BmobUser *user = [BmobUser getCurrentUser];
            [user updateCurrentUserPasswordWithOldPassword:DEFAULTUSERPASSWORD newPassword:@"12" block:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    //用新密码登录
                    [BmobUser loginInbackgroundWithAccount:@"Lily" andPassword:@"12" block:^(BmobUser *user, NSError *error) {
                        if (error) {
                            NSLog(@"login error:%@",error);
                        } else {
                            NSLog(@"修改密码后登录成功:%@",user);
                        }
                    }];
                } else {
                    NSLog(@"change password error:%@",error);
                }
            }];
        }
    }];
}

- (void)weiboLogin{
    [Util batchDeleteUser];
    //得到的新浪微博授权信息，请按照例子来生成NSDictionary
    NSDictionary *dic = @{@"access_token":@"2.00ff8sNGPTpgLD9e29daeabd09Am6e",@"uid":@"5701865443",@"expirationDate":[NSDate dateWithTimeIntervalSinceNow:1000]};
    //通过授权信息注册登录
    [BmobUser loginInBackgroundWithAuthorDictionary:dic platform:BmobSNSPlatformSinaWeibo block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"user objectid is :%@",user);
        }
    }];
}

- (void)qqLogin{
    [Util batchDeleteUser];
    //得到的qq授权信息，请按照例子来生成NSDictionary
    NSDictionary *dic = @{@"access_token":@"1234134",@"uid":@"1234fads",@"expirationDate":[NSDate dateWithTimeIntervalSinceNow:1000]};
    //通过授权信息注册登录
    [BmobUser loginInBackgroundWithAuthorDictionary:dic platform:BmobSNSPlatformQQ block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"user objectid is :%@",user);
        }
    }];
}

- (void)weixinLogin{
    [Util batchDeleteUser];
    //得到的微信授权信息，请按照例子来生成NSDictionary
    NSDictionary *dic = @{@"access_token":@"1234134",@"uid":@"1234fads",@"expirationDate":[NSDate dateWithTimeIntervalSinceNow:1000]};
    //通过授权信息注册登录
    [BmobUser loginInBackgroundWithAuthorDictionary:dic platform:BmobSNSPlatformWeiXin block:^(BmobUser *user, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"user objectid is :%@",user);
        }
    }];
    
}

- (void)bindUser{
    [Util batchDeleteUser];
    BmobUser *bUser = [[BmobUser alloc] init];
    [bUser setUserName:@"小明"];
    [bUser setPassword:@"123456"];
    [bUser setObject:@18 forKey:@"age"];
    [bUser signUpInBackgroundWithBlock:^ (BOOL isSuccessful, NSError *error){
        if (isSuccessful){
            NSDictionary *dic = @{@"access_token":@"token",@"uid":@"uid",@"expirationDate":[NSDate dateWithTimeIntervalSinceNow:100]};
            BmobUser *currentUser = [BmobUser getCurrentUser];
            [currentUser linkedInBackgroundWithAuthorDictionary:dic platform:BmobSNSPlatformSinaWeibo block:^(BOOL isSuccessful, NSError *error) {
                NSLog(@"ERROR :%@",[error description]);
            }];
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)unbindUser{
    //当前用户解除关联的微博账号
    [Util batchDeleteUser];
    BmobUser *bUser = [[BmobUser alloc] init];
    [bUser setUserName:@"小明"];
    [bUser setPassword:@"123456"];
    [bUser setObject:@18 forKey:@"age"];
    [bUser signUpInBackgroundWithBlock:^ (BOOL isSuccessful, NSError *error){
        if (isSuccessful){
            NSDictionary *dic = @{@"access_token":@"token",@"uid":@"uid",@"expirationDate":[NSDate dateWithTimeIntervalSinceNow:100]};
            BmobUser *currentUser = [BmobUser getCurrentUser];
            [currentUser linkedInBackgroundWithAuthorDictionary:dic platform:BmobSNSPlatformSinaWeibo block:^(BOOL isSuccessful, NSError *error) {
                [currentUser cancelLinkedInBackgroundWithPlatform:BmobSNSPlatformSinaWeibo block:^(BOOL isSuccessful, NSError *error) {
                    if (error) {
                        NSLog(@"%@",error);
                    } else {
                        NSLog(@"解绑成功");
                    }
                }];
            }];
        } else {
            NSLog(@"%@",error);
        }
    }];
}


# pragma mark - 手机相关功能，需要将手机号填写上去
- (void)mobilePhoneRegister{
    [Util batchDeleteUser];
    BmobUser *buser = [[BmobUser alloc] init];
    buser.mobilePhoneNumber = @"15123456789";
    buser.password = @"123";
    buser.email = @"xxx@gmail.com";
    [buser signUpOrLoginInbackgroundWithSMSCode:@"6位验证码" block:^(BOOL isSuccessful, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            BmobUser *user = [BmobUser getCurrentUser];
            NSLog(@"%@",[BmobUser getCurrentUser]);
        }
    }];
}

- (void)mobilePhoneLogin{
    [Util batchDeleteUser];
    [BmobUser loginInbackgroundWithMobilePhoneNumber:@"" andSMSCode:@"smsCode" block:^(BmobUser *user, NSError *error) {
        if (user) {
            NSLog(@"%@",user);
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)bindMobilePhone{
    [Util batchDeleteUser];
    [BmobSMS verifySMSCodeInBackgroundWithPhoneNumber:@"mobilePhoneNumber" andSMSCode:@"smsCode" resultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //修改绑定手机
            BmobUser *buser = [BmobUser getCurrentUser];
            buser.mobilePhoneNumber = @"mobilePhoneNumber";
            [buser setObject:[NSNumber numberWithBool:YES] forKey:@"mobilePhoneNumberVerified"];
            [buser updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    NSLog(@"%@",buser);
                } else {
                    NSLog(@"%@",error);
                }
            }];
            
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)changePasswordByMobilePhone{
    [Util batchDeleteUser];
    [BmobUser resetPasswordInbackgroundWithSMSCode:@"smsCode" andNewPassword:@"newPassword" block:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            NSLog(@"%@",@"重置密码成功");
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)emailVerify{
    [Util batchDeleteUser];
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD,@"email":@"397524331@qq.com"}
                              ];
    [Util batchAddUserWithDataArray:addUserArray];
    [BmobUser loginWithUsernameInBackground:@"Lily" password:DEFAULTUSERPASSWORD block:^(BmobUser *user, NSError *error) {
        //应用开启了邮箱验证功能
        if ([user objectForKey:@"emailVerified"]) {
            //用户没验证过邮箱
            if (![[user objectForKey:@"emailVerified"] boolValue]) {
                [user verifyEmailInBackgroundWithEmailAddress:@"xxxxxxxxxx"];
            }
        }
    }];
    

}

@end
