//
//  BmobObjectDemoViewController.h
//  BmobSDK
//
//  Created by 林涛 on 15/12/10.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "BaseViewController.h"

@interface BmobObjectDemoViewController : BaseViewController

@end
