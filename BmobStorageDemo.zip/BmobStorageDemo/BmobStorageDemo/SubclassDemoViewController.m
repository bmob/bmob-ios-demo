//
//  SubclassDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "SubclassDemoViewController.h"
#import "Test.h"
#import <BmobSDK/Bmob.h>
#import "TestUser.h"
#import "Util.h"

@interface SubclassDemoViewController ()

@end

@implementation SubclassDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"子类化BmobObject",@"detail":@"subClassBmobObject"},
                       @{@"title":@"子类化BmobUser",@"detail":@"subClassBmobUser"},
                       @{@"title":@"子类化查询",@"detail":@"subClassQuery"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self subClassBmobObject];
        }
            break;
            
        case 1:{
            [self subClassBmobUser];
        }
            break;
            
        case 2:{
            [self subClassQuery];
        }
            break;
            
        default:
            break;
    }
}

# pragma mark - demo
- (void)subClassBmobObject{
    Test *test = [[Test alloc] init];
    test.title = @"title2";
    test.name = @"name2";
    test.isStudent = [NSNumber numberWithBool:NO];
    test.age = @22;
    [test sub_saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"添加成功");
        }
    }];
}

- (void)subClassBmobUser{
    [Util batchDeleteUser];
    BmobUser *bUser = [[BmobUser alloc] init];
    [bUser setUserName:@"小明"];
    [bUser setPassword:@"123456"];
    [bUser setObject:@18 forKey:@"age"];
    [bUser signUpInBackgroundWithBlock:^ (BOOL isSuccessful, NSError *error){
        if (isSuccessful){
            TestUser *user = [[TestUser alloc] initFromBmobObject:[BmobUser getCurrentUser]];
            user.email = @"xxxaa@qq.com";
            [user sub_updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                NSLog(@"error %@",error.description);
            }];
        } else {
            NSLog(@"%@",error);
        }
    }];
    

}

- (void)subClassQuery{
    static NSString *tableName = @"Test";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"title":@"title1"},
                                @{@"title":@"title2"}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isAdd) {
        BmobQuery *testQuery = [Test query];
        [testQuery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            for (BmobObject *obj in array) {
                Test *t = [[Test alloc] initFromBmobObject:obj];
                NSLog(@"%@",t.title);
            }
        }];
    }
}

@end
