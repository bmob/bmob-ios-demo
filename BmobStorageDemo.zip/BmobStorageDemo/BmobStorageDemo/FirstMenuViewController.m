//
//  FirstMenuViewController.m
//  BmobSDK
//
//  Created by lishiquan on 15/12/9.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "FirstMenuViewController.h"
#import "BmobObjectDemoViewController.h"
#import "BmobQueryDemoViewController.h"
#import "ArrayDemoViewController.h"
#import "RelationshipDemoViewController.h"
#import "UserDemoViewController.h"
#import "SubclassDemoViewController.h"
#import "FileDemoViewController.h"
#import "RealTimeDemoViewController.h"
#import "ACLDemoViewController.h"
#import "PositionDemoViewController.h"
#import "CloudCodeDemoViewController.h"
#import "SMSDemoViewController.h"
#import "OtherDemoViewController.h"


@interface FirstMenuViewController ()

@end

@implementation FirstMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dateArray = @[
                       @{@"title":@"对象BmobObject",@"detail":@"基本BmobObject用法，增删改查"},
                       @{@"title":@"查询BmobQuery",@"detail":@"基本BmobQuery用法"},
                       @{@"title":@"数组",@"detail":@"数组的使用"},
                       @{@"title":@"关联关系",@"detail":@"数据关联"},
                       @{@"title":@"用户",@"detail":@"用户的基本用法"},
                       @{@"title":@"子类化",@"detail":@"子类化的使用"},
                       @{@"title":@"文件管理",@"detail":@"文件管理"},
                       @{@"title":@"数据实时功能",@"detail":@"数据实时功能的基本使用"},
                       @{@"title":@"ACL和角色",@"detail":@"ACL和角色的基本使用"},
                       @{@"title":@"地理位置",@"detail":@"地理位置的基本使用"},
                       @{@"title":@"云端代码",@"detail":@"云端代码的基本使用"},
                       @{@"title":@"短信服务",@"detail":@"短信服务的基本使用"},
                       @{@"title":@"其它功能",@"detail":@"其它功能基本使用"}];
}


# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self jumpToDemoViewControllerWithClassName:@"BmobObjectDemoViewController"];
        }
            break;
            
        case 1:{
            [self jumpToDemoViewControllerWithClassName:@"BmobQueryDemoViewController"];
        }
            break;
            
        case 2:{
            [self jumpToDemoViewControllerWithClassName:@"ArrayDemoViewController"];
        }
            break;
            
        case 3:{
            [self jumpToDemoViewControllerWithClassName:@"RelationshipDemoViewController"];
        }
            break;
            
        case 4:{
            [self jumpToDemoViewControllerWithClassName:@"UserDemoViewController"];
        }
            break;
            
        case 5:{
            [self jumpToDemoViewControllerWithClassName:@"SubclassDemoViewController"];
        }
            break;
            
        case 6:{
            [self jumpToDemoViewControllerWithClassName:@"FileDemoViewController"];
        }
            break;
            
         
        case 7:{
            [self jumpToDemoViewControllerWithClassName:@"RealTimeDemoViewController"];
        }
            break;
            
        case 8:{
            [self jumpToDemoViewControllerWithClassName:@"ACLDemoViewController"];
        }
            break;
            
        case 9:{
            [self jumpToDemoViewControllerWithClassName:@"PositionDemoViewController"];
        }
            break;
            
        case 10:{
            [self jumpToDemoViewControllerWithClassName:@"CloudCodeDemoViewController"];
        }
            break;
            
        case 11:{
            [self jumpToDemoViewControllerWithClassName:@"SMSDemoViewController"];
        }
            break;
            
        case 12:{
            [self jumpToDemoViewControllerWithClassName:@"OtherDemoViewController"];
        }
            break;
            
        default:
            break;
    }
}

- (void)jumpToDemoViewControllerWithClassName:(NSString *)viewControllerName{
    id vc = [[NSClassFromString(viewControllerName) alloc] init];
    if (vc) {
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
