//
//  CloudCodeDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "CloudCodeDemoViewController.h"
#import "Util.h"
#import <BmobSDK/Bmob.h>

@interface CloudCodeDemoViewController ()

@end

@implementation CloudCodeDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"同步调用云端代码",@"detail":@"synCloudCodeCall"},
                       @{@"title":@"异步调用云端代码",@"detail":@"asynCloudCodeCall"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self synCloudCodeCall];
        }
            break;
            
        case 1:{
            [self asynCLoudCodeCall];
        }
            break;
            
        default:
            break;
    }
}

# pragma mark - demo
- (void)synCloudCodeCall{
    /**
     云端代码，方法名为：synCall
        function onRequest(request, response, modules) {
            //获取数据库对象
            var db = modules.oData;
            //获取Posts表中的所有值
            db.find({
            "table":request.body.tableName,
            },function(err,data){
                response.send(data);
            });
        }
     */
    [Util batchDeleteTableAllRecordWithTableName:@"Post"];
    [Util batchAddWithTableName:@"Post" andDataArray:@[@{@"title":@"test"}]];
    NSDictionary *dic = [BmobCloud callFunction:@"synCall" withParameters:@{@"tableName":@"Post"}];
    NSLog(@"%@",dic);
}

- (void)asynCLoudCodeCall{
    /**
     云端代码，方法名为：asynCall
     function onRequest(request, response, modules) {
     //获取数据库对象
     var db = modules.oData;
     //获取Posts表中的所有值
     db.find({
     "table":request.body.tableName,
     },function(err,data){
     response.send(data);
     });
     }
     */
    [Util batchDeleteTableAllRecordWithTableName:@"Post"];
    [Util batchAddWithTableName:@"Post" andDataArray:@[@{@"title":@"test"}]];
    [BmobCloud callFunctionInBackground:@"asynCall" withParameters:@{@"tableName":@"Post"} block:^(id object, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"%@",object);
        }
    }];
}

@end
