//
//  FileDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "FileDemoViewController.h"
#import <BmobSDK/Bmob.h>
#import "Util.h"
#import <BmobSDK/BmobProFile.h>

@interface FileDemoViewController ()

@end

@implementation FileDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"旧文件上传",@"detail":@"oldUploadFile"},
                       @{@"title":@"旧文件分片上传",@"detail":@"oldUploadFileBySlide"},
                       @{@"title":@"旧文件批量上传",@"detail":@"oldBatchUploadFile"},
                       @{@"title":@"旧文件下载",@"detail":@"oldDownloadFile"},
                       @{@"title":@"旧文件图片处理",@"detail":@"oldDealImageFile"},
                       @{@"title":@"新文件路径上传",@"detail":@"newUploadFileByPath"},
                       @{@"title":@"新文件NSData上传",@"detail":@"newUploadFileByData"},
                       @{@"title":@"新文件批量上传",@"detail":@"newBatchUploadFile"},
                       @{@"title":@"新文件路径批量上传",@"detail":@"newBatchUploadFileByPath"},
                       @{@"title":@"新文件路径下载",@"detail":@"newDownloadFileByFilename"},
                       @{@"title":@"新文件获取直接访问url",@"detail":@"newGetAccessURL"},
                       @{@"title":@"新文件删除文件",@"detail":@"deleteFile"},
                       @{@"title":@"新文件图片服务器处理",@"detail":@"newDealImageFileByServer"},
                       @{@"title":@"新文件图片本地处理",@"detail":@"newDealImageFileByClient"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self oldUploadFile];
        }
            break;
            
        case 1:{
            [self oldUploadFileBySlide];
        }
            break;
            
        case 2:{
            [self oldBatchUploadFile];
        }
            break;
            
        case 3:{
            [self oldDownloadFile];
        }
            break;
            
        case 4:{
            [self oldDealImageFile];
        }
            break;
            
        case 5:{
            [self newUploadFileByPath];
        }
            break;
            
        case 6:{
            [self newUploadFileByData];
        }
            break;
            
        case 7:{
            [self newBatchUploadFile];
        }
            break;
            
        case 8:{
            [self newBatchUploadFileByPath];
        }
            break;
            
        case 9:{
            [self newDownloadFileByFilename];
        }
            break;
            
        case 10:{
            [self newGetAccessURL];
        }
            break;
            
        case 11:{
            [self deleteFile];
        }
            break;
            
        case 12:{
            [self newDealImageFileByServer];
        }
            break;
            
        case 13:{
            [self newDealImageFileByClient];
        }
            break;
            
        default:
            break;
    }
}

- (void)oldUploadFile{
    NSBundle    *bundle = [NSBundle mainBundle];
    NSString *fileString = [NSString stringWithFormat:@"%@/test.txt" ,[bundle bundlePath] ];
    BmobObject *obj = [[BmobObject alloc] initWithClassName:@"GameScoreFile"];
    BmobFile *file1 = [[BmobFile alloc] initWithClassName:@"Asc" withFilePath:fileString];
    [file1 saveInBackground:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            [obj setObject:file1  forKey:@"userFile"];
            [obj saveInBackground];
            NSLog(@"file1 url %@",file1.url);
        } else {
            NSLog(@"%@",error);
        }
    } withProgressBlock:^(float progress) {
        NSLog(@"上传进度%.2f",progress);
    }];
}

- (void)oldUploadFileBySlide{
    NSBundle    *bundle = [NSBundle mainBundle];
    //上传cs.txt文件
    NSString *fileString = [NSString stringWithFormat:@"%@/cncc.jpg" ,[bundle bundlePath] ];
    BmobObject *obj = [[BmobObject alloc] initWithClassName:@"GameScoreFile"];
    //创建BmobFile对象
    BmobFile *file1 = [[BmobFile alloc] initWithFilePath:fileString];
    [file1 saveInBackgroundByDataSharding:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //如果成功，保存文件到userFile
            [obj setObject:file1  forKey:@"userFile"];
            [obj saveInBackground];
            NSLog(@"%@",file1.url);
        }else{
            //失败，打印错误信息
            NSLog(@"error: %@",[error description]);
        }
    } progressBlock:^(float progress) {
        NSLog(@"%.2f",progress);
    }] ;
}

- (void)oldBatchUploadFile{
    NSBundle    *bundle = [NSBundle mainBundle];
    //文件cncc.jpg的路径
    NSString *fileString = [NSString stringWithFormat:@"%@/cncc.jpg" ,[bundle bundlePath]];
    //文件cs.txt的路径
    NSString *fileString2 = [NSString stringWithFormat:@"%@/test.txt" ,[bundle bundlePath]];
    
    [BmobFile filesUploadBatchWithPaths:@[fileString,fileString2]
                          progressBlock:^(int index, float progress) {
                              //index 上传数组的下标，progress当前文件的进度
                              NSLog(@"index %d progress %f",index,progress);
                          } resultBlock:^(NSArray *array, BOOL isSuccessful, NSError *error) {
                              if (isSuccessful) {
                                  NSLog(@"%@",array);
                                  
                                  //array 文件数组，isSuccessful 成功或者失败,error 错误信息
                                  BmobObject *obj = [[BmobObject alloc] initWithClassName:@"GameScoreFile"];
                                  for (int i = 0 ; i < array.count ;i ++) {
                                      BmobFile *file = array [i];
                                      NSString *key = [NSString stringWithFormat:@"userFile%d",i];
                                      [obj setObject:file  forKey:key];
                                  }
                                  
                                  [obj saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                                      if (isSuccessful) {
                                          NSLog(@"保存成功");
                                      }
                                  }];
                              } else {
                                  NSLog(@"%@",error);
                              }
                          }];
}

- (void)oldDownloadFile{
    NSBundle    *bundle = [NSBundle mainBundle];
    NSString *fileString = [NSString stringWithFormat:@"%@/test.txt" ,[bundle bundlePath] ];
    BmobObject *obj = [[BmobObject alloc] initWithClassName:@"GameScoreFile"];
    BmobFile *file1 = [[BmobFile alloc] initWithClassName:@"Asc" withFilePath:fileString];
    [file1 saveInBackground:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            [obj setObject:file1  forKey:@"userFile"];
            [obj saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                
                //保存至表中的BmobFile可以跟普通字段一样读取下来，然后去url下载即可
                BmobFile *file = (BmobFile*)[obj objectForKey:@"userFile"];
                NSLog(@"%@",file.url);
                NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:file.url]];
                NSString *fileContent = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                NSLog(@"%@",fileContent);
            }];
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)oldDealImageFile{
    NSBundle    *bundle = [NSBundle mainBundle];
    NSString *fileString = [NSString stringWithFormat:@"%@/nv.jpg" ,[bundle bundlePath] ];
    BmobFile *file = [[BmobFile alloc] initWithClassName:@"Asc" withFilePath:fileString];
    [file saveInBackground:^(BOOL isSuccessful, NSError *error) {
        
        if (isSuccessful) {
            
            [BmobImage thumbnailImageBySpecifiesTheHeight:100 quality:50 sourceImageUrl:file.url outputType:kBmobImageOutputBmobFile resultBlock:^(id object, NSError *error) {
                if (error) {
                    NSLog(@"%@",error);
                } else {
                    NSLog(@"%@",(BmobFile*)object);
                }
            }];
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)newUploadFileByPath{
    //构造文件路径
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    path                 = [path stringByAppendingPathComponent:@"nv.jpg"];
    [BmobProFile uploadFileWithPath:path block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
        if (isSuccessful) {
            //上传成功后返回文件名及url
            NSLog(@"filename:%@",filename);
            NSLog(@"url:%@",url);
            NSLog(@"bmobFile:%@\n",bmobFile);
        } else{
            if(error){
                NSLog(@"error%@",error);
            }
        }
    } progress:^(CGFloat progress) {
        //上传进度，此处可编写进度条逻辑
        NSLog(@"progress %f",progress);
    }];
}

- (void)newUploadFileByData{
    //构造NSData
    NSString *mainBundlePath = [[NSBundle mainBundle] bundlePath];
    NSData *data = [NSData dataWithContentsOfFile:[mainBundlePath stringByAppendingPathComponent:@"nv.jpg"]];
    
    //上传文件
    [BmobProFile uploadFileWithFilename:@"nv.jpg" fileData:data block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
        if (isSuccessful) {
            //打印文件名
            NSLog(@"filename %@",filename);
            //打印url
            NSLog(@"url %@",url);
            NSLog(@"bmobFile:%@\n",bmobFile);
        } else {
            if (error) {
                NSLog(@"error %@",error);
            }
        }
    } progress:^(CGFloat progress) {
        //上传进度，此处可编写进度条逻辑
        NSLog(@"progress %f",progress);
    }];
}

- (void)newBatchUploadFile{
    //构造上传文件data字典数组
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    NSString *path1 = [path stringByAppendingPathComponent:@"nv.jpg"];
    NSString *path2 = [path stringByAppendingPathComponent:@"cncc.jpg"];
    NSString *path3 = [path stringByAppendingPathComponent:@"test.txt"];
    
    NSData* data1 = [NSData dataWithContentsOfFile:path1];
    NSData* data2 = [NSData dataWithContentsOfFile:path2];
    NSData* data3 = [NSData dataWithContentsOfFile:path3];
    
    NSDictionary *dic1 = [[NSDictionary alloc] initWithObjectsAndKeys:@"nv.jpg",@"filename",data1,@"data",nil];
    NSDictionary *dic2 = [[NSDictionary alloc] initWithObjectsAndKeys:@"cncc.jpg",@"filename",data2,@"data",nil];
    NSDictionary *dic3 = [[NSDictionary alloc] initWithObjectsAndKeys:@"test.txt",@"filename",data3,@"data",nil];
    
    NSArray *array = @[dic1,dic2,dic3];
    
    //上传文件，dataArray 数组中存放NSDictionary，NSDictionary里面的格式为@{@"filename":@"你的文件名",@"data":文件的data}
    [BmobProFile uploadFilesWithDatas:array resultBlock:^(NSArray *filenameArray, NSArray *urlArray, NSArray *bmobFileArray,NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            //路径数组和url数组（url数组里面的元素为NSString）
            NSLog(@"fileArray %@ urlArray %@",filenameArray,urlArray);
            for (BmobFile* bmobFile in bmobFileArray ) {
                NSLog(@"%@",bmobFile);
            }
        }
    } progress:^(NSUInteger index, CGFloat progress) {
        //index表示正在上传的文件其路径在数组当中的索引，progress表示该文件的上传进度
        NSLog(@"index %lu progress %f",(unsigned long)index,progress);
    }];
    
    

}

- (void)newBatchUploadFileByPath{
    //构造上传文件路径数组
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    NSString *path1 = [path stringByAppendingPathComponent:@"nv.jpg"];
    NSString *path2 = [path stringByAppendingPathComponent:@"cncc.jpg"];
    NSString *path3 = [path stringByAppendingPathComponent:@"test.txt"];
    NSArray *array = @[path1,path2,path3];
    
    //上传文件
    [BmobProFile uploadFilesWithPaths:array resultBlock:^(NSArray *pathArray, NSArray *urlArray,NSArray *bmobFileArray,NSError *error) {
        //路径数组和url数组（url数组里面的元素为NSString）
        if (error) {
            NSLog(@"%@",error);
        } else {
            //路径数组和url数组（url数组里面的元素为NSString）
            NSLog(@"pathArray %@ urlArray %@",pathArray,urlArray);
            for (BmobFile* bmobFile in bmobFileArray ) {
                NSLog(@"%@",bmobFile);
            }
        }
    } progress:^(NSUInteger index, CGFloat progress) {
        //index表示正在上传的文件其路径在数组当中的索引，progress表示该文件的上传进度
        NSLog(@"index %lu progress %f",(unsigned long)index,progress);
    }];
}

- (void)newDownloadFileByFilename{
    
    //构造文件路径
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    path                 = [path stringByAppendingPathComponent:@"nv.jpg"];
    [BmobProFile uploadFileWithPath:path block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
        if (isSuccessful) {
            
            //下载
            [BmobProFile downloadFileWithFilename:filename block:^(BOOL isSuccessful, NSError *error, NSString *filepath) {
                //下载的文件所存放的路径
                if (isSuccessful) {
                    NSLog(@"filepath:%@",filepath);
                } else if (error) {
                    NSLog(@"%@",error);
                } else {
                    NSLog(@"Unknow error");
                }
            } progress:^(CGFloat progress) {
                //下载的进度
                NSLog(@"progress %f",progress);
            }];
        } else{
            if(error){
                NSLog(@"error%@",error);
            }
        }
    } progress:^(CGFloat progress) {
        //上传进度，此处可编写进度条逻辑
        NSLog(@"progress %f",progress);
    }];
    
}

- (void)newGetAccessURL{
    
    //构造文件路径
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    path                 = [path stringByAppendingPathComponent:@"nv.jpg"];
    [BmobProFile uploadFileWithPath:path block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
        if (isSuccessful) {
            [BmobProFile getFileAcessUrlWithFileName:filename callBack:^(BmobFile *file, NSError *error) {
                if (error) {
                    NSLog(@"%@",error);
                } else {
                    NSLog(@"%@",file);
                }
            }];

        } else{
            if(error){
                NSLog(@"error%@",error);
            }
        }
    }  progress:^(CGFloat progress) {
        //上传进度，此处可编写进度条逻辑
        NSLog(@"progress %f",progress);
    }];
}

- (void)deleteFile{
    
    //构造文件路径
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    path                 = [path stringByAppendingPathComponent:@"nv.jpg"];
    [BmobProFile uploadFileWithPath:path block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
        if (isSuccessful) {
            
            [BmobProFile deleteFileWithFileName:filename callBack:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    NSLog(@"delete successfully");
                } else {
                    NSLog(@"%@",error);
                }
            }];
            
        } else{
            if(error){
                NSLog(@"error%@",error);
            }
        }
    }  progress:^(CGFloat progress) {
        //上传进度，此处可编写进度条逻辑
        NSLog(@"progress %f",progress);
    }];
}

- (void)newDealImageFileByServer{
    //构造文件路径
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    path                 = [path stringByAppendingPathComponent:@"nv.jpg"];
    [BmobProFile uploadFileWithPath:path block:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
        if (isSuccessful) {
            
            [BmobProFile thumbnailImageWithFilename:filename ruleID:1 resultBlock:^(BOOL isSuccessful, NSError *error, NSString *filename, NSString *url,BmobFile *bmobFile) {
                //缩略图的文件名
                NSLog(@"filename %@",filename);
                //缩略图的url地址
                NSLog(@"fileUrl  %@",url);
                NSLog(@"error    %@",error);
            }];
        
        } else{
            if(error){
                NSLog(@"error%@",error);
            }
        }
    }  progress:^(CGFloat progress) {
        //上传进度，此处可编写进度条逻辑
        NSLog(@"progress %f",progress);
    }];
    
    


}

- (void)newDealImageFileByClient{

    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *path       = [mainBundle bundlePath];
    path                 = [path stringByAppendingPathComponent:@"nv.jpg"];
    [BmobProFile localThumbnailImageWithFilepath:path ruleID:1 resultBlock:^(BOOL isSuccessful, NSError *error, NSString *filepath){
        //打印缩略图文件路径
        NSLog(@"filepath  %@",filepath);
    }];

}

@end
