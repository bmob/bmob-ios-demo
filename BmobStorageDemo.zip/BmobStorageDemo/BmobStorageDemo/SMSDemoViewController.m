//
//  SMSDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "SMSDemoViewController.h"
#import <BmobSDK/Bmob.h>

@interface SMSDemoViewController ()

@end

@implementation SMSDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"发送短信",@"detail":@"sendSMS"},
                       @{@"title":@"发送短信验证码",@"detail":@"endSMSCode"},
                       @{@"title":@"验证短信验证码",@"detail":@"verifySMSCode"},
                       @{@"title":@"查询短信验证码状态",@"detail":@"querySMSCodeStatus"},
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self sendSMS];
        }
            break;
            
        case 1:{
            [self sendSMSCode];
        }
            break;
            
        case 2:{
            [self verifySMSCode];
        }
            break;
            
        case 3:{
            [self querySMSCodeStatus];
        }
            break;
            
        default:
            break;
    }
}

# pragma mark - demo
- (void)sendSMS{
    [BmobSMS requestSMSInbackgroundWithPhoneNumber:@"phoneNumber" Content:@"您的XX服务还有XX时间到期，请及时续费。" andSendTime:@"2015-07-01 10:59:00" resultBlock:^(int number, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"smsId:%d",number);
        }
    }];
}

- (void)sendSMSCode{
    [BmobSMS requestSMSCodeInBackgroundWithPhoneNumber:@"mobilePhoneNumber" andTemplate:@"test" resultBlock:^(int number, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            //获得smsID
            NSLog(@"sms ID：%d",number);
        }
    }];
}

- (void)verifySMSCode{
    //验证
    [BmobSMS verifySMSCodeInBackgroundWithPhoneNumber:@"mobilePhoneNumber" andSMSCode:@"smsCode"resultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            NSLog(@"%@",@"验证成功，可执行用户请求的操作");
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)querySMSCodeStatus{
    [BmobSMS querySMSCodeStateInBackgroundWithSMSId:123456 resultBlock:^(NSDictionary *dic, NSError *error) {
        if (dic) {
            NSLog(@"%@",dic);
        } else {
            NSLog(@"%@",error);
        }
    }];
}

@end
