//
//  FirstMenuViewController.h
//  BmobSDK
//
//  Created by lishiquan on 15/12/9.
//  Copyright © 2015年 donson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface FirstMenuViewController : BaseViewController

@end
