//
//  SubclassDemoViewController.h
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "BaseViewController.h"

@interface SubclassDemoViewController : BaseViewController

@end
