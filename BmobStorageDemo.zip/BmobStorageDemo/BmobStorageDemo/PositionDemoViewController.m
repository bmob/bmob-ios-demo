//
//  PositionDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "PositionDemoViewController.h"
#import <BmobSDK/Bmob.h>
#import "Util.h"

@interface PositionDemoViewController ()

@end

@implementation PositionDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"创建地理位置",@"detail":@"createBmobGeoPoint"},
                       @{@"title":@"查询地址位置",@"detail":@"queryBmobGeoPoint"}

                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self createBmobGeoPoint];
        }
            break;
            
        case 1:{
            [self queryBmobGeoPoint];
        }
            break;
            
        default:
            break;
    }
}

# pragma mark - demo
- (void)createBmobGeoPoint{
    static NSString *tableName = @"GameScore";
    [Util batchDeleteTableAllRecordWithTableName:tableName];
    BmobGeoPoint *point = [[BmobGeoPoint alloc] initWithLongitude:116 WithLatitude:39];
    BmobObject *gameScore = [BmobObject objectWithClassName:tableName];
    [gameScore setObject:point forKey:@"location"];
    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            NSLog(@"%@",gameScore);
        }
    }];
}

//TODO
- (void)queryBmobGeoPoint{
    static NSString *tableName = @"GameScore";
    [Util batchDeleteTableAllRecordWithTableName:tableName];
    [Util batchAddWithTableName:tableName andDataArray:@[@{@"location":@{
                                                             @"__type": @"GeoPoint",
                                                             @"latitude": @100,
                                                             @"longitude": @20
                                                             }},
                                                         @{@"location":@{
                                                             @"__type": @"GeoPoint",
                                                             @"latitude": @101,
                                                             @"longitude": @21
                                                             }}]];
    [Util batchAddWithTableName:tableName andDataArray:@[@{@"ttest":@1}]];
    BmobGeoPoint  *point = [[BmobGeoPoint alloc] initWithLongitude:116.39727786183357 WithLatitude:39.913768382429105];
    BmobQuery *bquery = [BmobQuery queryWithClassName:tableName];
    [bquery whereKey:@"location" nearGeoPoint:point];
    [bquery setLimit:10];
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        //进行操作
        if (error) {
            NSLog(@"%@",error);
        } else {
            for (BmobObject *obj in array) {
                NSLog(@"%@",obj);
            }
        }
    }];
}

@end
