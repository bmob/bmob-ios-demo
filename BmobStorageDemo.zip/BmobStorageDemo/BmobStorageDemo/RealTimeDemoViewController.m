//
//  RealTimeDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "RealTimeDemoViewController.h"
#import <BmobSDK/Bmob.h>

@interface RealTimeDemoViewController ()<BmobEventDelegate>
@property (strong, nonatomic) BmobEvent *bmobEvent;
@end

@implementation RealTimeDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"监听表数据",@"detail":@"listen"},
                       @{@"title":@"取消监听表数据",@"detail":@"cancelListen"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self listen];
        }
            break;
            
        case 1:{
            [self cancelListen];
        }
            break;
            
        default:
            break;
    }
}

# pragma mark - demo
- (void)listen{
    //创建BmobEvent对象
    self.bmobEvent          = [BmobEvent defaultBmobEvent];
    //设置代理
    self.bmobEvent.delegate = self;
    //启动连接
    [self.bmobEvent start];
}

- (void)cancelListen{
    [self.bmobEvent cancelListenTableChange:BmobActionTypeUpdateTable tableName:@"Post"];
}

//可以进行监听或者取消监听事件
-(void)bmobEventCanStartListen:(BmobEvent *)event{
    //监听Post表更新
    [self.bmobEvent listenTableChange:BmobActionTypeUpdateTable tableName:@"Post"];
}
//接收到得数据
-(void)bmobEvent:(BmobEvent *)event didReceiveMessage:(NSString *)message{
    //打印数据
    NSLog(@"didReceiveMessage:%@",message);
}

@end
