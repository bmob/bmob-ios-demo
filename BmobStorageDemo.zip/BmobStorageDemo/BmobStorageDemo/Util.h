//
//  Util.h
//  BmobSDK
//
//  Created by 林涛 on 15/12/17.
//  Copyright © 2015年 donson. All rights reserved.
//

#import <Foundation/Foundation.h>


#define DEFAULTUSERPASSWORD @"1"

@interface Util : NSObject
+ (NSArray *)queryTableAllRecordWithTableName:(NSString *)tableName;
+ (BOOL)batchDeleteTableAllRecordWithTableName:(NSString *)tableName;
+ (BOOL)batchAddWithTableName:(NSString *)tableName andDataArray:(NSArray *)dataArray;
+ (NSArray *)batchAddWithTableName:(NSString *)tableName DataArray:(NSArray *)dataArray;
+ (NSArray *)batchAddUserWithDataArray:(NSArray *)dataArray;
+ (BOOL)batchDeleteUser;
@end
