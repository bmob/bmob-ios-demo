//
//  BmobQueryDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/15.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "BmobQueryDemoViewController.h"
#import <BmobSDk/Bmob.h>
#import "Util.h"



@interface BmobQueryDemoViewController ()

@end

@implementation BmobQueryDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dateArray = @[
                       @{@"title":@"查询单条数据",@"detail":@"singleQuery"},
                       @{@"title":@"查询多条数据",@"detail":@"compoundQuery"},
                       @{@"title":@"比较查询",@"detail":@"compoundQuery"},
                       @{@"title":@"包含查询",@"detail":@"cotainQuery"},
                       @{@"title":@"检查键值是否存在",@"detail":@"keyExistQuery"},
                       @{@"title":@"模糊查询",@"detail":@"regexQuery"},
                       @{@"title":@"页查询",@"detail":@"pageQuery"},
                       @{@"title":@"排序查询",@"detail":@"orderQuery"},
                       @{@"title":@"与复合查询",@"detail":@"orderQuery"},
                       @{@"title":@"或复合查询",@"detail":@"orderQuery"},
                       @{@"title":@"选择返回键值",@"detail":@"orderQuery"},
                       @{@"title":@"查询结果计数",@"detail":@"orderQuery"},
                       @{@"title":@"统计查询方法",@"detail":@"orderQuery"},
                       @{@"title":@"分组查询",@"detail":@"orderQuery"},
                       @{@"title":@"分组查询计数",@"detail":@"orderQuery"},
                       @{@"title":@"分组查询结果条件过滤",@"detail":@"orderQuery"},
                       @{@"title":@"bql查询",@"detail":@"orderQuery"},
                       @{@"title":@"bql统计查询",@"detail":@"orderQuery"},
                       @{@"title":@"bql占位符查询",@"detail":@"orderQuery"},
                       @{@"title":@"bql统计占位符查询",@"detail":@"orderQuery"},
                       ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self singleQuery];
        }
            break;
            
        case 1:{
            [self compoundQuery];
        }
            break;
            
        case 2:{
            [self compareQuery];
        }
            break;
            
        case 3:{
            [self containQuery];
        }
            break;
            
        case 4:{
            [self keyExistQuery];
        }
            break;
            
        case 5:{
            [self regexQuery];
        }
            break;
            
        case 6:{
            [self pageQuery];
        }
            break;
            
        case 7:{
            [self orderQuery];
        }
            break;
            
        case 8:{
            [self andQuery];
        }
            break;
            
        case 9:{
            [self orQuery];
        }
            break;
            
        case 10:{
            [self selectReturnKey];
        }
            break;
            
        case 11:{
            [self countQuery];
        }
            break;
            
        case 12:{
            [self calcQuery];
        }
            break;
            
        case 13:{
            [self groupbyQuery];
        }
            break;
            
        case 14:{
            [self groupbyCountQuery];
        }
            break;
            
        case 15:{
            [self havingQuery];
        }
            break;
            
        case 16:{
            [self bqlQuery];
        }
            break;
            
        case 17:{
            [self bqlCountQuery];
        }
            break;
            
        case 18:{
            [self bqlPlaceholdQuery];
        }
            break;
            
        case 19:{
            [self bqlCountPlaceholdQuery];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - demo
- (void)singleQuery{
    //创建并上传记录
    BmobObject *bObject = [BmobObject objectWithClassName:@"GameScore"];
    [bObject setObject:@"single query" forKey:@"tip"];
    NSLog(@"%@",bObject);
    [bObject saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
           
            //单条查询
            //查找GameScore表
            BmobQuery  *bquery = [BmobQuery queryWithClassName:@"GameScore"];
            [bquery getObjectInBackgroundWithId:@"0547707c91" block:^(BmobObject *object,NSError *error){
                if (error){
                    //进行错误处理
                    NSLog(@"%@",error);
                }else{
                    NSLog(@"%@",object);
                }
            }];
        } else {
            NSLog(@"%@",error);
        }
    }];
    
}

- (void)compoundQuery{
    BmobQuery   *bquery = [BmobQuery queryWithClassName:@"GameScore"];
    //查找GameScore表的数据
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        for (BmobObject *obj in array) {
            NSLog(@"%@",obj);
        }
    }];
}

- (void)compareQuery{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                           @{@"score":@11},
                           @{@"score":@78}
                           ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        [query whereKey:@"score" greaterThan:@30];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }

    
}

- (void)containQuery{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily"},
                                @{@"name":@"Lucy"},
                                @{@"name":@"Tiger"}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        [query whereKey:@"name" containedIn:@[@"Lily",@"Tiger",@"Mike"]];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)keyExistQuery{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@11},
                                @{@"name":@"Lucy"}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        [query whereKeyExists:@"score"];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)regexQuery{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lin Ming"},
                                @{@"name":@"Lily"},
                                @{@"name":@"Lin Jingjing"}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        [query whereKey:@"name" startWithString:@"Lin"];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)pageQuery{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"score":@1},
                                @{@"score":@2},
                                @{@"score":@1},
                                @{@"score":@2},
                                @{@"score":@1},
                                @{@"score":@2},
                                @{@"score":@1},
                                @{@"score":@2}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        query.limit = 3;
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)orderQuery{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"score":@1},
                                @{@"score":@2},
                                @{@"score":@7},
                                @{@"score":@9},
                                @{@"score":@14},
                                @{@"score":@6},
                                @{@"score":@17},
                                @{@"score":@10}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        [query orderByAscending:@"score"];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",[obj objectForKey:@"score"]);
                }
            }
        }];
    }
}

- (void)andQuery{
    //查询score列中值等于5且姓名为Mike的数据
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@5},
                                @{@"name":@"Mike",@"score":@2},
                                @{@"name":@"Mike",@"score":@5}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        NSArray *array =  @[@{@"name":@"Mike"},@{@"score":@5}];
        [query addTheConstraintByAndOperationWithArray:array];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)orQuery{
    //查询score列中值等于5且姓名为Mike的数据
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1},
                                @{@"name":@"Mike",@"score":@2},
                                @{@"name":@"Mike",@"score":@5}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        NSArray *array =  @[@{@"name":@"Mike"},@{@"score":@5}];
        [query addTheConstraintByOrOperationWithArray:array];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)selectReturnKey{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1,@"country":@"China"},
                                @{@"name":@"Mike",@"score":@2,@"country":@"China"},
                                @{@"name":@"Mike",@"score":@5,@"country":@"China"}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];

        [query selectKeys:@[@"name",@"score"]];
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)countQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1,@"country":@"China"},
                                @{@"name":@"Mike",@"score":@2,@"country":@"China"},
                                @{@"name":@"Mike",@"score":@5,@"country":@"China"}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        [query countObjectsInBackgroundWithBlock:^(int number, NSError *error) {
            NSLog(@"%d",number);
        }];
    }
}

- (void)calcQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"score":@1},
                                @{@"score":@2},
                                @{@"score":@7}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        NSArray *sumArray = [NSArray arrayWithObject:@"score"];
        [query sumKeys:sumArray];
        [query calcInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"%@",array);
                NSDictionary *dic = [[NSDictionary alloc] init];
                dic = [array objectAtIndex:0];
                NSLog(@"sum of score:%d",[[dic objectForKey:@"_sumScore"] intValue]);
            }
        }];
    }
}

- (void)groupbyQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1},
                                @{@"name":@"Lily",@"score":@2},
                                @{@"name":@"Li Ming",@"score":@7}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        NSArray *groupbyArray = [NSArray arrayWithObject:@"name"];
        [query groupbyKeys:groupbyArray];
        NSArray *sumArray = [NSArray arrayWithObject:@"score"];
        [query sumKeys:sumArray];
        [query calcInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"%@",array);
                for (NSDictionary *dic in array) {
                    NSString *playerName = [dic objectForKey:@"name"];
                    NSString *sum = [dic objectForKey:@"_sumScore"];
                    NSLog(@"player:%@\tsum:%@",playerName,sum);
                }
            }
        }];
    }
    
}

- (void)groupbyCountQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1},
                                @{@"name":@"Lily",@"score":@2},
                                @{@"name":@"Li Ming",@"score":@7}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        NSArray *groupbyArray = [NSArray arrayWithObject:@"name"];
        [query groupbyKeys:groupbyArray];
        NSArray *sumArray = [NSArray arrayWithObject:@"score"];
        [query sumKeys:sumArray];
        query.isGroupcount = YES;
        [query calcInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"%@",array);
                for (NSDictionary *dic in array) {
                    NSString *playerName = [dic objectForKey:@"name"];
                    NSString *sum = [dic objectForKey:@"_sumScore"];
                    NSLog(@"player:%@\tsum:%@",playerName,sum);
                }
            }
        }];
    }
}

- (void)havingQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1},
                                @{@"name":@"Lily",@"score":@2},
                                @{@"name":@"Li Ming",@"score":@7}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *query = [BmobQuery queryWithClassName:tableName];
        
        NSArray *groupbyArray = [NSArray arrayWithObject:@"name"];
        [query groupbyKeys:groupbyArray];
        
        NSArray *sumArray = [NSArray arrayWithObject:@"score"];
        [query sumKeys:sumArray];
        
        [query constructHavingDic:@{@"_sumScore":@{@"$gt":@4}}];
        
        [query calcInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"%@",array);
                for (NSDictionary *dic in array) {
                    NSString *playerName = [dic objectForKey:@"name"];
                    NSString *sum = [dic objectForKey:@"_sumScore"];
                    NSLog(@"player:%@\tsum:%@",playerName,sum);
                }
            }
        }];
    }
}

- (void)bqlQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1},
                                @{@"name":@"Lily",@"score":@2},
                                @{@"name":@"Li Ming",@"score":@7}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *bmobQuery = [[BmobQuery alloc] init];
        NSString *bql = @"select * from GameScore";
        [bmobQuery queryInBackgroundWithBQL:bql block:^(BQLQueryResult *result, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                if (result) {
                    for (BmobObject *obj in result.resultsAry) {
                        NSLog(@"%@",obj);
                    }
                }
            }
        }];
    }
}

- (void)bqlCountQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@1},
                                @{@"name":@"Lily",@"score":@2},
                                @{@"name":@"Li Ming",@"score":@7}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *bmobQuery = [[BmobQuery alloc] init];
        NSString *bql = @"select sum(score) from GameScore";
        [bmobQuery statisticsInBackgroundWithBQL:bql block:^(NSArray *result, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"%@",result);
            }
        }];
    }
}

- (void)bqlPlaceholdQuery{
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[
                                @{@"name":@"Lily",@"score":@2},
                                @{@"name":@"Lily",@"score":@2},
                                @{@"name":@"Li Ming",@"score":@7}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        BmobQuery *bmobQuery = [[BmobQuery alloc] init];
        NSString *bql = @"select * from GameScore where name = ? and score = ?";
        NSArray *placeholderArray = @[@"Lily",@2];
        [bmobQuery queryInBackgroundWithBQL:bql pvalues:placeholderArray block:^(BQLQueryResult *result, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                if (result) {
                    for (BmobObject *obj in result.resultsAry) {
                        NSLog(@"%@",obj);
                    }
                }
            }
        }];
    }
}

- (void)bqlCountPlaceholdQuery{
    
}





@end
