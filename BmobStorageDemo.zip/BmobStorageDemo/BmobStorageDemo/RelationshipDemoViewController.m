//
//  RelationshipDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "RelationshipDemoViewController.h"
#import <BmobSDk/Bmob.h>
#import "Util.h"

@interface RelationshipDemoViewController ()

@end

@implementation RelationshipDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"添加pointer",@"detail":@"saveObject"},
                       @{@"title":@"删除pointer",@"detail":@"saveObject"},
                       @{@"title":@"更新pointer",@"detail":@"saveObject"},
                       @{@"title":@"获取pointer指向对象",@"detail":@"saveObject"},
                       @{@"title":@"查询约束pointer",@"detail":@"saveObject"},
                       @{@"title":@"添加relation",@"detail":@"saveObject"},
                       @{@"title":@"删除relation",@"detail":@"saveObject"},
                       @{@"title":@"更新relation",@"detail":@"saveObject"},
                       @{@"title":@"获取relation对象",@"detail":@"saveObject"},
                       @{@"title":@"查询约束relation",@"detail":@"saveObject"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
            
        case 0:{
            [self addPointer];
        }
            break;
            
        case 1:{
            [self deletePointer];
        }
            break;
            
        case 2:{
            [self updatePointer];
        }
            break;
            
        case 3:{
            [self getPointer];
        }
            break;
            
        case 4:{
            [self queryPointer];
        }
            break;
            
        case 5:{
            [self addRelation];
        }
            break;
            
        case 6:{
            [self deleteRelation];
        }
            break;
            
        case 7:{
            [self updateRelation];
        }
            break;
            
        case 8:{
            [self getRelation];
        }
            break;
            
        case 9:{
            [self queryRelation];
        }
            break;
            
        default:
            break;
    }
}

- (void)addPointer{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[@{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}];
    NSArray *results = [Util batchAddUserWithDataArray:addUserArray];
    
    if (results) {
        BmobObject  *post = [BmobObject objectWithClassName:postTable];
        //设置帖子的标题和内容
        [post setObject:@"" forKey:@"title"];
        [post setObject:@"..." forKey:@"content"];
        
        //设置帖子关联的作者记录
        BmobUser *author = [BmobUser objectWithoutDatatWithClassName:@"_User" objectId:results[0][@"objectId"]];
        [post setObject:author forKey:@"author"];
        
        //异步保存
        [post saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (isSuccessful) {
                //创建成功，返回objectId，updatedAt，createdAt等信息
                NSLog(@"%@",post);
            }else{
                if (error) {
                    NSLog(@"%@",error);
                }
            }
        }];
    }
}

- (void)deletePointer{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[@{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[@{@"title":@"How to user pointer",@"author":@{@"__type":@"Pointer",@"className":@"User",@"objectId":users[0][@"objectId"]}}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    
    if (users && posts) {
        NSString *postObjectId = posts[0][@"success"][@"objectId"];
        BmobQuery *query = [BmobQuery queryWithClassName:postTable];
        [query getObjectInBackgroundWithId:postObjectId block:^(BmobObject *object, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"删除前author有值%@",object);
                [object deleteForKey:@"author"];
                [object updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                    if (error) {
                        NSLog(@"%@",error);
                    } else {
                        [query getObjectInBackgroundWithId:postObjectId block:^(BmobObject *object, NSError *error) {
                            if (error) {
                                NSLog(@"%@",error);
                            } else {
                                NSLog(@"删除后，无author%@",object);
                            }
                        }];
                    }
                }];
                
            }
        }];
    }
}

- (void)updatePointer{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD}];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    //添加post，先关联Lily
    NSArray *addPostArray = @[@{@"title":@"How to user pointer",@"author":@{@"__type":@"Pointer",@"className":@"User",@"objectId":users[0][@"objectId"]}}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    
    if (users && posts) {
        //修改关联为Lucy
        NSString *postId = posts[0][@"success"][@"objectId"];
        BmobQuery *query = [BmobQuery queryWithClassName:postTable];
        [query getObjectInBackgroundWithId:postId block:^(BmobObject *object, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"修改前%@",object);
                BmobUser *user = [BmobUser objectWithoutDatatWithClassName:@"_User" objectId:users[1][@"objectId"]];
                [object setObject:user forKey:@"author"];
                [object updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                    if (error) {
                        NSLog(@"%@",error);
                    } else {
                        [query getObjectInBackgroundWithId:postId block:^(BmobObject *object, NSError *error) {
                            if (error) {
                                NSLog(@"%@",error);
                            } else {
                                NSLog(@"修改后%@",object);
                            }
                        }];
                    }
                }];
            }
        }];
    }
}

- (void)getPointer{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[@{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD}];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[@{@"title":@"How to user pointer",@"author":@{@"__type":@"Pointer",@"className":@"User",@"objectId":users[0][@"objectId"]}}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    
    if (users && posts) {
        NSString *postObjectId = posts[0][@"success"][@"objectId"];
        BmobQuery *query = [BmobQuery queryWithClassName:postTable];
        [query includeKey:@"author"];
        [query getObjectInBackgroundWithId:postObjectId block:^(BmobObject *object, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"author值%@",[object objectForKey:@"author"]);
            }
        }];
    }
}

- (void)queryPointer{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD}
                              ];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[
                              @{@"title":@"post1",@"author":@{@"__type":@"Pointer",@"className":@"User",@"objectId":users[0][@"objectId"]}},
                              @{@"title":@"post2",@"author":@{@"__type":@"Pointer",@"className":@"User",@"objectId":users[1][@"objectId"]}}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    
    if (users && posts) {
        BmobQuery *query = [BmobQuery queryWithClassName:postTable];
        
        BmobQuery *inQuery = [BmobQuery queryForUser];
        [inQuery whereKey:@"username" equalTo:@"Lily"];
        
        [query whereKey:@"author" matchesQuery:inQuery];
        [query includeKey:@"author"];
        
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)addRelation{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD}
                              ];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[@{@"title":@"post1"}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    
    if (users && posts) {
        //获取要添加关联关系的post
        NSString *postId = posts[0][@"success"][@"objectId"];
        BmobObject *post = [BmobObject objectWithoutDatatWithClassName:@"Post" objectId:postId];
        
        //新建relation对象
        BmobRelation *relation = [[BmobRelation alloc] init];
        [relation addObject:[BmobObject objectWithoutDatatWithClassName:@"_User" objectId:users[0][@"objectId"]]];
        [relation addObject:[BmobObject objectWithoutDatatWithClassName:@"_User" objectId:users[1][@"objectId"]]];
        
        //添加关联关系到likes列中
        [post addRelation:relation forKey:@"likes"];
        //异步更新obj的数据
        [post updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (isSuccessful) {
                BmobQuery *query = [BmobQuery queryWithClassName:postTable];
                [query getObjectInBackgroundWithId:postId block:^(BmobObject *object, NSError *error) {
                    if (error) {
                        NSLog(@"%@",error);
                    } else {
                        NSLog(@"%@",object);
                    }
                }];
            }else{
                NSLog(@"error %@",[error description]);
            }
        }];
    }
    
}

- (void)deleteRelation{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD}
                              ];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[@{@"title":@"post1",
                                @"likes":@{
                                        @"__op":@"AddRelation",
                                        @"objects":@[
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[0][@"objectId"]},
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[1][@"objectId"]}]}}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    NSString *postId = posts[0][@"success"][@"objectId"];
    
    BmobQuery *query = [BmobQuery queryWithClassName:@"Post"];
    
    [query getObjectInBackgroundWithId:postId block:^(BmobObject *object, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {

            //新建relation对象
            BmobRelation *relation = [[BmobRelation alloc] init];
            [relation removeObject:[BmobObject objectWithoutDatatWithClassName:@"_User" objectId:users[1][@"objectId"]]];
            //添加关联关系到likes列中
            [object addRelation:relation forKey:@"likes"];
            [object updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (error) {
                    NSLog(@"%@",error);
                } else {
                    NSLog(@"删除成功，可去web端查看");
                }
            }];
        }
    }];


}

- (void)updateRelation{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD}
                              ];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[@{@"title":@"post1",
                                @"likes":@{
                                        @"__op":@"AddRelation",
                                        @"objects":@[
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[0][@"objectId"]},
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[1][@"objectId"]}]}}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    NSString *postId = posts[0][@"success"][@"objectId"];
    
    BmobQuery *query = [BmobQuery queryWithClassName:@"Post"];
    
    [query getObjectInBackgroundWithId:postId block:^(BmobObject *object, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            //新建relation对象
            BmobRelation *relation = [[BmobRelation alloc] init];
            [relation addObject:[BmobObject objectWithoutDatatWithClassName:@"_User" objectId:users[1][@"objectId"]]];
            //添加关联关系到likes列中
            [object addRelation:relation forKey:@"likes"];
            [object updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (error) {
                    NSLog(@"%@",error);
                } else {
                    NSLog(@"更新成功，可去web端查看");
                }
            }];
        }
    }];
}

- (void)getRelation{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Ming",@"password":DEFAULTUSERPASSWORD}
                              ];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[@{@"title":@"post1",
                                @"likes":@{
                                        @"__op":@"AddRelation",
                                        @"objects":@[
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[0][@"objectId"]},
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[1][@"objectId"]}]}}];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    NSString *postId = posts[0][@"success"][@"objectId"];
    
    //关联对象表
    BmobQuery *bquery = [BmobQuery queryWithClassName:@"_User"];
    
    //需要查询的列
    BmobObject *post = [BmobObject objectWithoutDatatWithClassName:@"Post" objectId:postId];
    [bquery whereObjectKey:@"likes" relatedTo:post];
    
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            for (BmobObject *user in array) {
                NSLog(@"%@",[user objectForKey:@"username"]);
            }
        }
    }];

}

- (void)queryRelation{
    //删除旧数据
    static NSString *postTable = @"Post";
    [Util batchDeleteTableAllRecordWithTableName:postTable];
    [Util batchDeleteUser];
    
    //添加用户
    NSArray *addUserArray = @[
                              @{@"username":@"Lily",@"password":DEFAULTUSERPASSWORD},
                              @{@"username":@"Lucy",@"password":DEFAULTUSERPASSWORD}
                              ];
    NSArray *users = [Util batchAddUserWithDataArray:addUserArray];
    
    NSArray *addPostArray = @[
                              @{@"title":@"post1",
                                @"likes":@{
                                        @"__op":@"AddRelation",
                                        @"objects":@[
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[0][@"objectId"]},
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[1][@"objectId"]}]}},
                              @{@"title":@"post2",
                                @"likes":@{
                                        @"__op":@"AddRelation",
                                        @"objects":@[
                                                @{@"__type":@"Pointer",@"className":@"_User",@"objectId":users[0][@"objectId"]}]}
                                }
                              
                              ];
    NSArray *posts = [Util batchAddWithTableName:postTable DataArray:addPostArray];
    
    BmobQuery *bquery = [BmobQuery queryWithClassName:@"Post"];
    //构造约束条件
    BmobQuery *inQuery = [BmobQuery queryWithClassName:@"_User"];
    [inQuery whereKey:@"username" equalTo:@"Lucy"];
    
    //匹配查询
    [bquery whereKey:@"likes" matchesQuery:inQuery];
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else if (array){
            for (BmobObject *post in array) {
                NSLog(@"%@",post);
            }
        }
    }];
}

@end
