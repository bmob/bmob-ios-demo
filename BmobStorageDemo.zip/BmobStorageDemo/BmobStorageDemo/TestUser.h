//
//  TestUser.h
//  BmobSDK
//
//  Created by 林涛 on 15/12/18.
//  Copyright © 2015年 donson. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BmobSDK/Bmob.h>

@interface TestUser : BmobUser

@end
