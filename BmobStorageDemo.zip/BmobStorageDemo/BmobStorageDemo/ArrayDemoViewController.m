//
//  ArrayDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "ArrayDemoViewController.h"
#import "Util.h"
#import <BmobSDk/Bmob.h>

@interface ArrayDemoViewController ()

@end

@implementation ArrayDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"添加数组数据",@"detail":@"singleQuery"},
                       @{@"title":@"删除数组数据",@"detail":@"singleQuery"},
                       @{@"title":@"更新数组数据",@"detail":@"singleQuery"},
                       @{@"title":@"查询数组数据",@"detail":@"singleQuery"},
                       @{@"title":@"查询JSON数组数据",@"detail":@"singleQuery"},
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self addArrayDate];
        }
            break;
            
        case 1:{
            [self deleteArrayDate];
        }
            break;
            
        case 2:{
            [self updateArrayDate];
        }
            break;
            
        case 3:{
            [self queryArrarDate];
        }
            break;
            
        case 4:{
            [self queryJsonArrayDate];
        }
            break;
            
        default:
            break;
    }
}

- (void)addArrayDate{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[@{@"name":@"Lily"}];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        NSString *objectId = [Util queryTableAllRecordWithTableName:tableName][0][@"objectId"];
        BmobObject *obj = [BmobObject objectWithoutDatatWithClassName:tableName objectId:objectId];
        [obj addObjectsFromArray:@[@"P1",@"P2"] forKey:@"skill"];
        [obj updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"添加成功，可在web端查看数据是否正确");
            }
        }];
    }
}

- (void)deleteArrayDate{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[@{@"name":@"Lily",@"skill":@[@"P1",@"P2",@"P3"]}];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        NSString *objectId = [Util queryTableAllRecordWithTableName:tableName][0][@"objectId"];
        BmobObject *obj = [BmobObject objectWithoutDatatWithClassName:tableName objectId:objectId];
        [obj removeObjectsInArray:@[@"P3"] forKey:@"skill"];
        [obj updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"删除成功，可在web端查看数据是否正确");
            }
        }];
    }
}

- (void)updateArrayDate{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[@{@"name":@"Lily",@"skill":@[@"P1",@"P2",@"P3"]}];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        NSString *objectId = [Util queryTableAllRecordWithTableName:tableName][0][@"objectId"];
        BmobObject *obj = [BmobObject objectWithoutDatatWithClassName:tableName objectId:objectId];
        [obj addUniqueObjectsFromArray:@[@"P3",@"P4"] forKey:@"skill"];
        [obj updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                NSLog(@"更新成功，可在web端查看数据是否正确");
            }
        }];
    }
}

- (void)queryArrarDate{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[@{@"name":@"Lily",@"skill":@[@"P1",@"P2",@"P3"]},
                                @{@"name":@"Lucy",@"skill":@[@"P1"]},
                                @{@"name":@"Ming",@"skill":@[@"P1",@"P2"]}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        //查询数组中包含某些元素的记录
        BmobQuery *query1 = [BmobQuery queryWithClassName:tableName];
        NSArray *array = @[@"P1",@"P2"];
        [query1 whereKey:@"skill" containsAll:array];
        [query1 findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                for (BmobObject *obj in array) {
                    NSLog(@"%@",obj);
                }
            }
        }];
    }
}

- (void)queryJsonArrayDate{
    //构造数据
    static NSString *tableName = @"GameScore";
    BOOL isDelete = [Util batchDeleteTableAllRecordWithTableName:tableName];
    NSArray *addObjectArray = @[@{@"projectExperiences":@[@{@"name":@"project1",@"descr":@"descr1"},
                                                          @{@"name":@"project2",@"descr":@"descr2"}]}
                                ];
    BOOL isAdd = [Util batchAddWithTableName:tableName andDataArray:addObjectArray];
    if (isDelete && isAdd) {
        NSString *objectId = [Util queryTableAllRecordWithTableName:tableName][0][@"objectId"];
        BmobObject *obj = [BmobObject objectWithoutDatatWithClassName:tableName objectId:objectId];
        [obj setObject:@"myProject" forKey:@"projectExperiences.0.name"];
        [obj setObject:@"myDescr" forKey:@"projectExperiences.1.descr"];
        [obj updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            } else {
                BmobQuery *query = [BmobQuery queryWithClassName:tableName];
                [query getObjectInBackgroundWithId:objectId block:^(BmobObject *object, NSError *error) {
                    if (error) {
                        NSLog(@"%@",error);
                    } else {
                        NSLog(@"%@",object);
                    }
                }];
            }
        }];
    }
}

@end
