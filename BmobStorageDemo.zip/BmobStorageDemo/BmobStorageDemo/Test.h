//
//  Test.h
//  BmobSDK
//
//  Created by 林涛 on 15/12/18.
//  Copyright © 2015年 donson. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BmobSDK/Bmob.h>

@interface Test : BmobObject
@property (copy, nonatomic) NSString *title;
@property (copy, nonatomic) NSString *name;
@property (strong, nonatomic) NSNumber *isStudent;
@property (strong, nonatomic) NSNumber *age;
@end
