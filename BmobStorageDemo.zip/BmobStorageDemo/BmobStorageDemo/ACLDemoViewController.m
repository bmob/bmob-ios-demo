//
//  ACLDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "ACLDemoViewController.h"
#import <BmobSDK/Bmob.h>
#import "Util.h"

@interface ACLDemoViewController ()

@end

@implementation ACLDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"全局读写设置",@"detail":@"saveObject"},
                       @{@"title":@"特定用户读写设置",@"detail":@"saveObject"},
                       @{@"title":@"特定用户群读写设置",@"detail":@"saveObject"},
                       @{@"title":@"读写设置继承",@"detail":@"saveObject"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self defaultACL];
        }
            break;
      
        case 1:{
            [self userAccessACL];
        }
            break;
            
        case 2:{
            [self bmobRole];
        }
            break;
            
        case 3:{
            [self bmobRoleInherit];
        }
            break;
            
            
        default:
            break;
    }
}

# pragma mark - demo
//全局可读可写设置
- (void)defaultACL{
    BmobACL *acl = [BmobACL ACL];
    //设置所有人读权限为true
    [acl setPublicReadAccess];
    //设置所有人写权限为true
    [acl setPublicWriteAccess];
}

//特定用户对表的读写操作
- (void)userAccessACL{

    //创建公司某用户的工资对象
    BmobObject *wageinfo  = [[BmobObject alloc] initWithClassName:@"wageinfo"];
    [wageinfo setObject:[NSNumber numberWithUnsignedInteger:100000] forKey:@"wage"];
    //这里创建四个用户对象，分别为老板、人事小张、出纳小谢和自己
    BmobUser *boss        = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    BmobUser *hr_zhang    = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    BmobUser *cashier_xie = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    BmobUser *me          = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    //创建ACL对象
    BmobACL *acl = [BmobACL ACL];
    //4个用户对象均可读
    [acl setReadAccessForUser:boss];
    [acl setReadAccessForUser:hr_zhang];
    [acl setReadAccessForUser:cashier_xie];
    [acl setReadAccessForUser:me];
    //设置boss跟hr_zhang 写的权限
    [acl setWriteAccessForUser:boss];
    [acl setWriteAccessForUser:hr_zhang];
    wageinfo.ACL= acl;
    [wageinfo saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //进行操作
        }else{
            //进行操作
        }
    }];
}

//特定群体对表的可读可写
- (void)bmobRole{
    //创建公司某用户的工资对象
    BmobObject *wageinfo  = [[BmobObject alloc] initWithClassName:@"wageinfo"];
    [wageinfo setObject:[NSNumber numberWithUnsignedInteger:100000] forKey:@"wage"];
    //这里创建5个用户对象，分别为老板、人事小张、人事小罗、出纳小谢和自己
    BmobUser *boss           = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    BmobUser *hr_zhang       = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    BmobUser *hr_luo         = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];;
    BmobUser *cashier_xie    = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    BmobUser *me             = [BmobUser objectWithoutDatatWithClassName:@"User" objectId:@"xxxxxx"];
    //创建HR和Cashier两个用户角色（这里为了举例BmobRole的使用，将这段代码写在这里，正常情况下放在员工管理界面会更合适）
    BmobRole *hr             = [BmobRole roleWithName:@"HR"];
    BmobRole *cashier        = [BmobRole roleWithName:@"Cashier"];
    //将hr_zhang和hr_luo归属到hr角色中
    BmobRelation *hrRelation = [BmobRelation relation];
    [hrRelation addObject:hr_zhang];
    [hrRelation addObject:hr_luo];
    [hr addUsersRelation:hrRelation];
    //保存到云端角色表中（web端可以查看Role表）
    [hr saveInBackground];
    //将cashier_xie归属到cashier角色中
    BmobRelation *cashierRelation = [BmobRelation relation];
    [cashierRelation addObject:cashier_xie];
    [cashier addUsersRelation:cashierRelation];
    //保存到云端角色表中（web端可以查看Role表）
    [cashier saveInBackground];
    //创建ACL对象
    BmobACL *acl = [BmobACL ACL];
    [acl setReadAccessForUser:boss];// 假设老板只有一个, 设置读权限
    [acl setReadAccessForUser:me];// 给自己设置读权限
    [acl setReadAccessForRole:hr];// 给hr角色设置读权限
    [acl setReadAccessForRole:cashier];// 给cashier角色设置读权限
    //设置boss跟hr_zhang 写的权限
    [acl setWriteAccessForUser:boss];// 设置老板拥有写权限
    [acl setWriteAccessForRole:hr];// 设置ht角色拥有写权限
    wageinfo.ACL= acl;
    [wageinfo saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //进行操作
        }else{
            //进行操作
        }
    }];
}

//权限的继承
- (void)bmobRoleInherit{
    //创建MobileDep（移动研发部）、AndroidTeam（android开发组）和iOSTeam（ios开发组）三个角色
    BmobRole *mobileDep =[BmobRole roleWithName:@"MobileDep"];
    BmobRole *androidTeam = [BmobRole roleWithName:@"AndroidTeam"];
    BmobRole *iosTeam     = [BmobRole roleWithName:@"iOSTeam"];
    //保存AndroidTeam和iosTeam角色到云端
    [androidTeam saveInBackground];
    [iosTeam saveInBackground];
    //将androidTeam和iosTeam两种角色添加到移动部门角色中
    BmobRelation *relation = [BmobRelation relation];
    [relation addObject:androidTeam];
    [relation addObject:iosTeam];
    [mobileDep addRolesRelation:relation];
    // 假设创建三个代码数据对象
    BmobObject *coreCode = [BmobObject objectWithClassName:@"Code"];
    BmobObject *androidCode = [BmobObject objectWithClassName:@"Code"];
    BmobObject *iosCode = [BmobObject objectWithClassName:@"Code"];
    //......此处省略一些具体的属性设定
    [coreCode saveInBackground];
    [androidCode saveInBackground];
    [iosCode saveInBackground];
    //设置androidTeam角色对androidCode对象的读和写的权限
    [androidCode.ACL setReadAccessForRole:androidTeam];
    [androidCode.ACL setWriteAccessForRole:androidTeam];
    //设置iosTeam角色对iosCode对象的读和写的权限
    [iosCode.ACL setReadAccessForRole:iosTeam];
    [iosCode.ACL setWriteAccessForRole:iosTeam];
    //设置mobileDep角色可以对coreCode对象进行读操作
    [coreCode.ACL setReadAccessForRole:mobileDep];
}

@end
