//
//  OtherDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/16.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "OtherDemoViewController.h"
#import <BmobSDK/Bmob.h>

@interface OtherDemoViewController ()

@end

@implementation OtherDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dateArray = @[
                       @{@"title":@"获取服务器时间戳",@"detail":@"getServerTime"},
                       @{@"title":@"设置超时时间",@"detail":@"setTimeoutTime"},
                       @{@"title":@"获取特定表结构",@"detail":@"getTableSchemas"},
                       @{@"title":@"获取所有表结构",@"detail":@"getAllTableSchemas"}
                       ];
}

# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self getServerTime];
        }
            break;
            
        case 1:{
            [self setTimeoutTime];
        }
            break;
            
        case 2:{
            [self getTableSchemas];
        }
            break;
            
        case 3:{
            [self getAllTableSchemas];
        }
            break;
            
        default:
            break;
    }
}

# pragma mark - demo
- (void)getServerTime{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //设置时区
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"Asia/Shanghai"]];
    //时间格式
    [dateFormatter setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
    //调用获取服务器时间接口，返回的是时间戳
    NSString  *timeString = [Bmob getServerTimestamp];
    //时间戳转化成时间
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[timeString intValue]];
    NSString *dateStr = [dateFormatter stringFromDate:date];
    NSLog(@"北京时间:%@",dateStr);
}


//TODO: demo
- (void)setTimeoutTime{
    [Bmob setBmobRequestTimeOut:15];
}

- (void)getTableSchemas{
    [Bmob getTableSchemasWithClassName:@"_User" callBack:^(BmobTableSchema *bmobTableSchema, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            //直接用description来查看表结构
            NSLog(@"%@",bmobTableSchema.description);
            
            /*
             分别打印表结构
             */
            //打印表名
            NSLog(@"表名:%@",bmobTableSchema.className);
            //打印表结构
            NSDictionary *fields = bmobTableSchema.fields;
            NSArray *allKey = [fields allKeys];
            for (NSString *key in allKey) {
                NSLog(@"列名:%@",key);
                NSDictionary *fieldStrcut = [fields objectForKey:key];
                NSLog(@"列类型:%@",[fieldStrcut objectForKey:@"type"] );
                if ([[fieldStrcut objectForKey:@"type"] isEqualToString:@"Pointer"]) {
                    NSLog(@"关联关系指向的表名:%@",[fieldStrcut objectForKey:@"targetClass"]);
                }
            }
        }
    }];
}

- (void)getAllTableSchemas{
    [Bmob getAllTableSchemasWithCallBack:^(NSArray *tableSchemasArray, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            for (BmobTableSchema* bmobTableSchema in tableSchemasArray) {
                //直接用description来查看表结构
                NSLog(@"%@",bmobTableSchema.description);
                
                /*
                 分别打印表结构
                 */
                //打印表名
                NSLog(@"表名:%@",bmobTableSchema.className);
                //打印表结构
                NSDictionary *fields = bmobTableSchema.fields;
                NSArray *allKey = [fields allKeys];
                for (NSString *key in allKey) {
                    NSLog(@"列名:%@",key);
                    NSDictionary *fieldStrcut = [fields objectForKey:key];
                    NSLog(@"列类型:%@",[fieldStrcut objectForKey:@"type"] );
                    if ([[fieldStrcut objectForKey:@"type"] isEqualToString:@"Pointer"]) {
                        NSLog(@"关联关系指向的表名:%@",[fieldStrcut objectForKey:@"targetClass"]);
                    }
                }
            }
        }
    }];
}
@end
