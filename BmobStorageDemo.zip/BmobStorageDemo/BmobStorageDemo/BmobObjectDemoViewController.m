//
//  BmobObjectDemoViewController.m
//  BmobSDK
//
//  Created by 林涛 on 15/12/10.
//  Copyright © 2015年 donson. All rights reserved.
//

#import "BmobObjectDemoViewController.h"
#import <BmobSDk/Bmob.h>

@interface BmobObjectDemoViewController ()

@end

@implementation BmobObjectDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dateArray = @[
                       @{@"title":@"保存对象",@"detail":@"saveObject"},
                       @{@"title":@"使用字典保存对象",@"detail":@"saveObject"},
                       @{@"title":@"删除对象",@"detail":@"deleteObject"},
                       @{@"title":@"更新对象",@"detail":@"upadteObject"},
                       @{@"title":@"更新json对象",@"detail":@"upadteObject"},
                       @{@"title":@"原子计数器",@"detail":@"atomicCounter"},
                       @{@"title":@"批量操作",@"detail":@"batchOperator"}
                       ];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}


# pragma mark - tableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:{
            [self saveObject];
        }
            break;
            
        case 1:{
            [self saveObjectWithDic];
        }
            break;
            
        case 2:{
            [self deleteObject];
        }
            break;
            
        case 3:{
            [self updateObject];
        }
            break;
            
        case 4:{
            [self updateObjectJSONField];
        }
            break;
            
        case 5:{
            [self atomicCounter];
        }
            break;
            
        case 6:{
            [self batchOperator];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - demo
- (void)saveObject{
    //在GameScore创建一条数据，如果当前没GameScore表，则会创建GameScore表
    BmobObject  *gameScore = [BmobObject objectWithClassName:@"GameScore"];
    //score为1200
    [gameScore setObject:[NSNumber numberWithInt:1200] forKey:@"score"];
    //设置userName为小明
    [gameScore setObject:@"小明" forKey:@"playerName"];
    //设置cheatMode为NO
    [gameScore setObject:[NSNumber numberWithBool:NO] forKey:@"cheatMode"];
    //设置age为18
    [gameScore setObject:[NSNumber numberWithInt:18] forKey:@"age"];
    [gameScore setObject:[NSDate date] forKey:@"time"];
    //异步保存到服务器
    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //创建成功后会返回objectId，updatedAt，createdAt等信息
            //创建对象成功，打印对象值
            NSLog(@"%@",gameScore);
        } else if (error){
            //发生错误后的动作
            NSLog(@"%@",error);
        } else {
            NSLog(@"Unknow error");
        }
    }];
}

- (void)saveObjectWithDic{
    BmobObject  *gameScore = [BmobObject objectWithClassName:@"GameScore"];
    //设置playerName列的值为小黑和age列的值18
    NSDictionary *dic = @{@"playerName":@"小黑",@"score":@18};
    [gameScore saveAllWithDictionary:dic];
    //异步保存
    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //创建成功后的动作
            NSLog(@"%@",gameScore);
        } else if (error){
            //发生错误后的动作
            NSLog(@"%@",error);
        } else {
            NSLog(@"Unknow error");
        }
    }];
}

- (void)deleteObject{
    //创建一条数据，并上传至服务器
    BmobObject  *gameScore = [BmobObject objectWithClassName:@"GameScore"];
    [gameScore setObject:[NSNumber numberWithInt:1200] forKey:@"score"];
    
    //异步保存到服务器
    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //创建成功后会返回objectId，updatedAt，createdAt等信息
            NSLog(@"创建成功，接下来进行删除操作");
            NSLog(@"%@",gameScore);
            
            //此处是删除操作
            [gameScore deleteInBackgroundWithBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    NSLog(@"删除成功");
                } else {
                    NSLog(@"%@",error);
                }
            }];
            
        } else if (error){
            //发生错误后的动作
            NSLog(@"%@",error);
        } else {
            NSLog(@"Unknow error");
        }
    }];
}

- (void)updateObject{
    //创建一条数据，并上传至服务器
    BmobObject  *gameScore = [BmobObject objectWithClassName:@"GameScore"];
    [gameScore setObject:[NSNumber numberWithInt:1200] forKey:@"score"];
    
    //异步保存到服务器
    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //创建成功后会返回objectId，updatedAt，createdAt等信息
            NSLog(@"创建成功,以下为对象值");
            NSLog(@"%@",gameScore);
            
            //此处是更新操作
            [gameScore setObject:[NSNumber numberWithInt:110] forKey:@"score"];
            [gameScore updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    NSLog(@"更新成功，以下为对象值，可以看到score值已经改变");
                    NSLog(@"%@",gameScore);
                } else {
                    NSLog(@"%@",error);
                }
            }];
            
        } else if (error){
            //发生错误后的动作
            NSLog(@"%@",error);
        } else {
            NSLog(@"Unknow error");
        }
    }];
}

- (void)updateObjectJSONField{
    //创建一条数据，并上传至服务器
    BmobObject  *gameScore = [BmobObject objectWithClassName:@"GameScore"];
    NSDictionary *json = @{@"name":@"John", @"gender":@"man"};
    [gameScore setObject:json forKey:@"userAttibute"];

    //异步保存到服务器
    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            //创建成功后会返回objectId，updatedAt，createdAt等信息
            NSLog(@"创建成功,以下为对象值");
            NSLog(@"%@",gameScore);
            
            //此处是更新操作
            BmobObject *gameScoreChanged = [BmobObject objectWithoutDatatWithClassName:@"GameScore" objectId:gameScore.objectId];
            [gameScoreChanged setObject:@"women" forKey:@"userAttibute.gender"];
            [gameScoreChanged updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    NSLog(@"更新成功，以下为对象值，可以看到json里面的gender已经改变");
                    NSLog(@"%@",gameScoreChanged);
                } else {
                    NSLog(@"%@",error);
                }
            }];
            
        } else if (error){
            //发生错误后的动作
            NSLog(@"%@",error);
        } else {
            NSLog(@"Unknow error");
        }
    }];
    

//    //创建一条数据，并上传至服务器
//    BmobObject  *gameScore = [BmobObject objectWithClassName:@"GameScore"];
//    NSDictionary *json = @{@"name":@"John", @"gender":@"man"};
//    [gameScore setObject:json forKey:@"userAttibute"];
//    
//    //异步保存到服务器
//    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
//        if (isSuccessful) {
//            //创建成功后会返回objectId，updatedAt，createdAt等信息
//            NSLog(@"创建成功,以下为对象值");
//            NSLog(@"%@",gameScore);
//            
//            //错误的做法，直接使用gameScore来设置，请观察gameScore值上传时的值
//            [gameScore setObject:@"women" forKey:@"userAttibute.gender"];
//            NSLog(@"上传前的gameScore对象值\n%@",gameScore);
//            [gameScore updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
//                if (isSuccessful) {
//                    NSLog(@"更新成功，以下为对象值，可以看到json里面的gender已经改变");
//                    NSLog(@"%@",gameScore);
//                } else {
//                    NSLog(@"%@",error);
//                }
//            }];
//            
//        } else if (error){
//            //发生错误后的动作
//            NSLog(@"%@",error);
//        } else {
//            NSLog(@"Unknow error");
//        }
//    }];
}


- (void)atomicCounter{
    //创建一条数据，并上传至服务器
    BmobObject  *gameScore = [BmobObject objectWithClassName:@"GameScore"];
    [gameScore setObject:@0 forKey:@"atomicCounter"];
    [gameScore saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            BmobObject *gameScoreToBeChanged = [BmobObject objectWithoutDatatWithClassName:@"GameScore" objectId:gameScore.objectId];
            [gameScoreToBeChanged incrementKey:@"atomicCounter"];
            [gameScoreToBeChanged updateInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
                if (isSuccessful) {
                    NSLog(@"添加成功，可在后台查看objectID为%@的atomicCounter的值是否为1",gameScoreToBeChanged.objectId);
                } else {
                    NSLog(@"%@",error);
                }
            }];
        } else {
            NSLog(@"%@",error);
        }
    }];
}

- (void)batchOperator{
    BmobObjectsBatch    *batch = [[BmobObjectsBatch alloc] init] ;
    //在GameScore表中创建一条数据
    [batch saveBmobObjectWithClassName:@"GameScore" parameters:@{@"aveScore": @{@"数学":@90},@"score":@78}];
    [batch saveBmobObjectWithClassName:@"GameScore" parameters:@{@"aveScore": @{@"数学":@39},@"score":@79}];
    
    //可结合条件查询进行批量删除
//    //在GameScore表中更新objectId为27eabbcfec的数据
//    [batch updateBmobObjectWithClassName:@"GameScore" objectId:@"27eabbcfec" parameters:@{@"score": @85}];
//    //在GameScore表中删除objectId为30752bb92f的数据
//    [batch deleteBmobObjectWithClassName:@"GameScore" objectId:@"30752bb92f"];
    [batch batchObjectsInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        if (isSuccessful) {
            NSLog(@"添加成功，可去后台查看是否成功添加记录");
        } else {
            NSLog(@"%@",error);
        }
    }];
}



@end
